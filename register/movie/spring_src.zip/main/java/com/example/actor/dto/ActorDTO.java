package com.example.actor.dto;

public class ActorDTO {
	private int actor_id;
	private String name;
	private String profile_path;
}
