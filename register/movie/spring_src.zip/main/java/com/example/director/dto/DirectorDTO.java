package com.example.director.dto;

public class DirectorDTO {
	private int director_id;
	private String name;
	private String profile_path;
}
