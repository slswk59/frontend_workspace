package com.example.genre.dto;

public class GenreDTO {
	private int genre_id;
	private String name;
	
}
