package com.example.list.dao;

public interface ListDAO {

}
