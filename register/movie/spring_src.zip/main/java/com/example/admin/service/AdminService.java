package com.example.admin.service;

public interface AdminService {

}
